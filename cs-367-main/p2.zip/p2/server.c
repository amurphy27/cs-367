/* server.c - code for server program. Do not rename this file */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>

#include "proj.h"

#define QLEN 6 //


int main(int argc, char **argv) {

    // Use code from demo_server.c to set up your sever and listen on a port.

    // TODO: Add server logic to accept and handle clients.

    return 0;
}

