/* client.c - code for client program. Do not rename this file */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <ctype.h>

#include "proj.h"

int main( int argc, char **argv) {

    // Use code from demo_client.c from Socket Lab to connect to your server.

    // TODO: Add client logic


    /*
     * To read from stdin, use read_stdin (in proj.c). After reading input, call "fflush(stdin);" to clear stdin.
     */
}

