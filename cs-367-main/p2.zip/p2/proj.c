
#include <stdio.h>
#include <string.h>

#include "proj.h"

int read_stdin(char *buf, int buf_len, int *more) {
    // TODO: Copy your implementation from project 1.

    return 0;
}
